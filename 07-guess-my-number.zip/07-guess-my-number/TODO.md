# Guess My Number

## Roadmap

1. En input-box där man kan gissa på ett tal. En knapp för att gissa.

  1.1. Visa resultatet i en alert.
  
  1.2. Visa resultatet i ett HTML-element.

2. Håll reda på tidigare gissade tal.

  2.1. Bara visa talen i ett HTML-element.

  2.2. Visa för varje tidigare gissat tal om det var för högt eller lågt.

  2.3. Visa antalet gissningar hittills.

3. Starta om spelet.

4. Håll reda på highscore.

5. Fråga efter namn på spelaren. Spara namnet med highscore.

6. Top 10 highscores.

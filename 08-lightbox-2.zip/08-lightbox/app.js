/**
 * Lightbox.
 *
 */

